// Swedish
language = {
  is_available: "är tillgänglig",
  click_here: "Klicka här för att ladda ner",
  update_now: "Uppdatera Nu",
  type_to_search: "Sök / filtrera",
  domoticz_settings_saved: "Domoticz inställningar sparat",
  theme_settings_saved: "Tema inställningar sparat",
  theme_restored: "Tema återställd",
  allow_new_hardware: "Tillåt ny hårdvara i 5 min",
  is: "är",
  timedout: "tidsgränsen uppnådd",
  mainmenu: "Huvud meny",
  you_have: "Du har",
  messages: "meddelande(n)",
  warning: "Varning",
  storage_removed: "Localstorage borttagen",
  clear_localstorage: "Rensa webbläsare",
  resetTheme_message: "Vill du återställa temat till standardinställningar eller bara radera webbläsarlagring"
};
