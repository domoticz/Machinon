 // Dutch
language = {
  is_available: "is available",
  click_here: "Click here to download",
  update_now: "Update Now",
  type_to_search: "Type to search",
  domoticz_settings_saved: "Domoticz settings saved",
  theme_settings_saved: "Theme settings saved",
  theme_restored: "Theme restored",
  allow_new_hardware: "Allow new hardware for 5 min",
  is: "is",
  timedout: "timed out",
  mainmenu: "Main menu",
  you_have: "You have",
  messages: "message(s)",
  warning: "Warning",
  storage_removed: "Localstorage removed",
  clear_localstorage: "Clear browser storage",
  resetTheme_message: "Do you want to reset the theme to default settings, or just clear browser storage"
};

